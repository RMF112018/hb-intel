# 04 — Prompt 02: Read Model, Fixtures, and Mock Provider

## Objective

Wire the HB Document Control Center contracts into deterministic read models, fixtures, and mock backend provider behavior.

This prompt must remain read-only/mock-only. No live file operations.

## Required prerequisite

Prompt 01 must be completed or the existing repo must already contain equivalent source-registry and contract models.

## Required repo audit first

Inspect:

```text
packages/models/src/pcc/PccReadModels.ts
backend/functions/src/hosts/pcc-read-model/
apps/project-control-center/src/api/
apps/project-control-center/src/surfaces/documents/
```

Do not re-read files still in current context.

## Implementation target

Add or update the HB Document Control Center read model to include:

1. `project`
   - `projectId`
   - `projectNumber`
   - `projectName`
   - `procoreProjectId`

2. `currentUser`
   - user ID;
   - display name;
   - actor role/persona;
   - project role or permission template if available.

3. `lanes`
   - `projectRecord`
   - `myProjectFiles`
   - `reviewsAndApprovals`
   - `externalSystems`

4. `warnings`
   - source warning records;
   - missing-config/access-issue/throttled/folder-pending states.

## Fixture requirements

Fixtures must include at least:

### Available state sample

- Project Record available with formal project files.
- My Project Files available with only current project folder.
- External Systems showing Procore configured, Adobe Sign configured/launch-only, Document Crunch missing-config or access-issue.
- Role/action permissions for at least PM, PX, Superintendent, Project Accounting, Executive Oversight, and PCC Admin.

### Guardrail sample

- The model must not include root `My Project Files` children.
- The model must not include other project folders.
- The model must not include external writeback action.
- The model must include disabled/hard-no action messaging where useful.

### Degraded state sample

- SharePoint source unavailable or missing-config.
- My Project Files pending initialization.
- External system access issue.
- Partial results/throttled state.

## Backend mock provider

If a mock provider already serves `/api/pcc/projects/{projectId}/document-control`, extend it to return the new read-model shape.

If not, add a read-only mock provider method consistent with existing provider patterns.

Do not add live Graph/Procore/Adobe/Document Crunch calls.

## Tests

Add or update tests to assert:

- read model shape;
- source registry values present;
- `procoreProjectId` present;
- three lanes present;
- no root `My Project Files` exposure;
- no other-project folder exposure;
- external writeback unavailable;
- degraded source states render/return deterministically.

## Validation

Run targeted tests consistent with repo scripts.

Also run:

```bash
git diff --check
md5 pnpm-lock.yaml
git status --short
```

## Final response format

Return:

1. Files changed.
2. Fixtures added/updated.
3. Mock provider changes.
4. Guardrail tests added.
5. Validation results.
6. Next prompt recommendation.
