# 02 — Recommended Implementation Sequence

Run the implementation in slices. Each slice should be separately validated before moving on.

## Slice 1 — Source registry and shared contracts

Goal:
- establish the HB Document Control Center contract vocabulary.

Likely files:
- `packages/models/src/pcc/DocumentControl.ts`
- `packages/models/src/pcc/PccReadModels.ts`
- `packages/models/src/pcc/index.ts`
- related tests if present.

Must include:
- three lanes;
- Project Document Source Registry;
- SharePoint binding;
- My Project Files policy and user/project binding;
- external source binding;
- source health states;
- action codes;
- role/action matrix;
- workflow/review states;
- universal hard-no rules.

Must not include:
- live Graph;
- runtime OneDrive folder creation;
- external APIs.

## Slice 2 — Fixtures and mock provider

Goal:
- create deterministic mock data/read model for HB Document Control Center.

Likely files:
- PCC fixtures in `apps/project-control-center/src/api/` or existing fixture locations;
- `backend/functions/src/hosts/pcc-read-model/read-models/pcc-mock-read-model-provider.ts`;
- read-model tests.

Must include:
- Project Record sample;
- My Project Files sample limited to current project folder;
- External Systems sample;
- missing-config/access-issue/throttled states;
- role/action permissions;
- review queue sample;
- audit sample or references.

## Slice 3 — SPFx three-lane UI shell

Goal:
- render HB Document Control Center with the three lanes.

Likely files:
- `apps/project-control-center/src/surfaces/documents/**`

Must include:
- module header renamed to HB Document Control Center;
- Project Record lane;
- My Project Files lane;
- External Systems lane;
- Reviews & Approvals summary if existing UI architecture supports it;
- hard guardrail warning;
- disabled action states;
- no runtime file operations.

## Slice 4 — Permission/action model rendering and guardrails

Goal:
- make permitted/disabled actions visible and enforce UI-level guardrails.

Must include:
- R01–R23 roles;
- PR/MP/SB/EX/WF action code display or derived allowed action states;
- Project Coordinator;
- no root My Project Files exposure;
- no other project folder exposure;
- no external writeback button/action.

## Slice 5 — Closeout docs and validation

Goal:
- document what was implemented and prove guardrails.

Must include:
- closeout doc if repo pattern supports it;
- validation evidence;
- no lockfile/package/deployment changes;
- residual issues and next recommended prompt.
