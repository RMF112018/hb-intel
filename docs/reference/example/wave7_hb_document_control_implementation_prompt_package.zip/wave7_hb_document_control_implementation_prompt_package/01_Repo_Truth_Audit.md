# 01 — Repo-Truth Audit

Run this before implementation.

## 1. Confirm repo state

```bash
cd /Users/bobbyfetting/hb-intel
git status --short
git branch --show-current
git log --oneline -12
```

Confirm:
- current branch;
- whether commit `1c90b66db` is in history;
- unrelated working-tree changes;
- whether any files needed for Wave 7 are already modified.

If unrelated changes exist in files you need to edit, stop and report before editing.

## 2. Confirm lockfile baseline

```bash
md5 pnpm-lock.yaml
```

Record the checksum. It must not change.

## 3. Audit governing docs

Inspect:

```text
docs/architecture/blueprint/sp-project-control-center/Project_Control_Center_Development_Roadmap.md
docs/architecture/blueprint/sp-project-control-center/HB_Project_Control_Center_Target_Architecture_Blueprint.md
docs/architecture/blueprint/sp-project-control-center/Standard_Project_Site_Template_Contract.md
docs/architecture/blueprint/sp-project-control-center/phase-3/01_PCC_Product_Architecture_and_User_Journey_Blueprint.md
docs/architecture/blueprint/sp-project-control-center/phase-3/05_Phase_3_Development_Roadmap_Updated.md
docs/architecture/blueprint/sp-project-control-center/phase-3/07_Phase_3_Module_Implementation_Plan.md
```

Search:

```bash
rg -n "HB Document Control Center|Project Record|My Project Files|External Systems|Project Document Source Registry|Project Coordinator|Project Engineer|procoreProjectId|R01|PR01|MP01|SB01|EX01|WF01" docs/architecture/blueprint/sp-project-control-center
```

Confirm:
- Wave 7 is HB Document Control Center;
- three lanes are documented;
- role/action model is documented;
- Project Coordinator is used;
- Responsibility Matrix remains Wave 11.

## 4. Audit existing PCC model files

Inspect:

```text
packages/models/src/pcc/DocumentControl.ts
packages/models/src/pcc/PccReadModels.ts
packages/models/src/pcc/PccUserRoles.ts
packages/models/src/pcc/PccCapabilities.ts
packages/models/src/pcc/TeamAccess.ts
packages/models/src/pcc/ExternalSystems.ts
packages/models/src/pcc/BusinessAuditEvent.ts
packages/models/src/pcc/index.ts
```

Search:

```bash
rg -n "DocumentControl|document-control|PccDocumentControl|PccPersona|PCC_PERSONAS|PCC_PERSONA_CAPABILITIES|BusinessAudit|ExternalSystems|TeamAccess" packages/models/src/pcc
```

Identify:
- existing document-control vocabulary;
- existing source IDs/action IDs;
- existing read-model shape;
- export patterns;
- test patterns.

## 5. Audit backend read-model patterns

Inspect:

```text
backend/functions/src/hosts/pcc-read-model/
```

Search:

```bash
rg -n "document-control|PccDocumentControl|getPccProjectDocumentControl|pcc-mock-read-model-provider|PccReadModelProvider" backend/functions/src/hosts/pcc-read-model
```

Identify:
- route registration pattern;
- provider interface pattern;
- mock provider fixture pattern;
- tests.

## 6. Audit SPFx document surface patterns

Inspect:

```text
apps/project-control-center/src/surfaces/documents/
apps/project-control-center/src/surfaces/teamAccess/
apps/project-control-center/src/surfaces/projectHome/
apps/project-control-center/src/api/
```

Search:

```bash
rg -n "documents|Document|PccDocuments|document-control|readModel|adapter|ViewModel|fixture" apps/project-control-center/src
```

Identify:
- current document surface;
- adapter pattern;
- fixture client pattern;
- card/surface styling conventions;
- tests.

## 7. Audit test commands

Inspect package scripts before running broad commands:

```bash
cat package.json
rg -n ""test"|"typecheck"|"lint"|"prettier"|vitest|tsc" package.json apps packages backend
```

Prefer targeted tests for files you modify.

## 8. Audit summary

Before editing, produce an internal summary:

- current relevant files;
- files to modify;
- files to avoid;
- existing patterns to extend;
- validation commands to run;
- risks/unknowns.
