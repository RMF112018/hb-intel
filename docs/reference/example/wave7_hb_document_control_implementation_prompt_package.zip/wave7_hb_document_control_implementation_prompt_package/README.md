# Wave 7 — HB Document Control Center Implementation Prompt Package

## Purpose

This package instructs a local code agent to begin **Phase 3 / Wave 7 implementation** for **HB Document Control Center** in the `hb-intel` repo.

The implementation starts with the safest foundation:

1. Source registry / read-model contracts
2. Fixtures and mock provider updates
3. Three-lane SPFx UI shell
4. Permission/action model rendering
5. Guardrail and regression tests
6. Documentation closeout

## Strict implementation posture

This package does **not** authorize live Microsoft Graph file operations, tenant mutation, Procore writeback, Adobe Sign execution, Document Crunch runtime integration, package/deployment changes, or `.sppkg` packaging.

The goal is to implement the **mock/read-model/UI foundation** that proves the architecture safely before any live file actions are introduced.

## Required repo

```bash
/Users/bobbyfetting/hb-intel
```

## Governing commit

The Wave 7 documentation architecture was updated in:

```text
1c90b66db — docs(pcc): update wave 7 document control architecture
```

The local code agent must audit repo truth against that commit and the current working tree before making changes.

## Package files

1. `00_Master_Execution_Prompt.md`
2. `01_Repo_Truth_Audit.md`
3. `02_Implementation_Sequence.md`
4. `03_Prompt_01_Source_Registry_Contracts.md`
5. `04_Prompt_02_Read_Model_Fixtures_Mock_Provider.md`
6. `05_Prompt_03_SPFX_Three_Lane_UI.md`
7. `06_Prompt_04_Permission_Action_Model_Guardrails.md`
8. `07_Prompt_05_Closeout_Docs_And_Validation.md`
9. `08_Reviewer_Prompt.md`

## Recommended usage

Run the prompts in order. Do not combine all prompts into one large coding pass unless the agent has strong repo context and can maintain tight scope control.

Each prompt must end with a validation summary and a clear statement of files changed.
