# 00 — Master Execution Prompt

You are a local code agent working in:

```bash
/Users/bobbyfetting/hb-intel
```

## Objective

Begin **Phase 3 / Wave 7 implementation** for **HB Document Control Center** using the architecture documentation committed in:

```text
1c90b66db — docs(pcc): update wave 7 document control architecture
```

The implementation must start with the **read-model/source-registry/mock/UI foundation** and must not perform live file operations.

## Execution scope

You are authorized to implement the first Wave 7 foundation slice:

1. Shared model contracts for HB Document Control Center:
   - source registry;
   - lanes;
   - source bindings;
   - source health states;
   - action codes;
   - role/action permissions;
   - review/workflow states;
   - audit event vocabulary where needed.

2. Fixture/mock read-model support:
   - sample Project Record lane;
   - sample My Project Files lane;
   - sample External Systems lane;
   - sample permission/action matrix;
   - source states;
   - review queues;
   - guardrail examples.

3. Backend read-model provider updates:
   - GET/read-only mock provider support only;
   - no Graph/PnP/SharePoint REST/Procore/Adobe/Document Crunch runtime calls;
   - no write routes unless contract-only tests already require them and they remain non-mutating.

4. SPFx UI shell:
   - render HB Document Control Center;
   - render three lanes: Project Record, My Project Files, External Systems;
   - render warnings, source states, allowed actions, disabled actions, and hard guardrails;
   - no live file operations.

5. Tests:
   - model/fixture tests;
   - mock provider tests;
   - UI adapter/render tests where repo patterns support them;
   - guardrail tests proving no root `My Project Files` exposure, no other-project folder exposure, no external writeback, and no direct live Graph usage.

6. Documentation closeout:
   - update or add Wave 7 implementation closeout docs if repo pattern supports it.

## Forbidden unless explicitly authorized later

Do not modify or introduce:

- live Microsoft Graph file operations;
- live SharePoint REST / PnP operations;
- OneDrive folder creation runtime;
- upload/download/copy-link runtime execution;
- Procore API runtime;
- Adobe Sign API runtime;
- Document Crunch runtime;
- external writeback/sync/mirror;
- tenant mutation;
- permission mutation;
- `.sppkg` packaging;
- deployment/workflow files;
- package manager changes;
- `pnpm-lock.yaml`;
- broad Graph permissions;
- production app settings;
- secrets.

## Key architecture requirements

Use the updated Wave 7 architecture as repo truth.

HB Document Control Center must include three lanes:

```text
Project Record
My Project Files
External Systems
```

The `My Project Files` hard guardrail must be enforced in contracts, fixtures, UI, and tests:

> The project-site instance of **HB Document Control Center** must never expose the user’s full OneDrive `My Project Files` root folder or folders for other projects. It may only resolve and display the folder mapped to the currently loaded project.

## Critical role/action requirement

The implementation must reflect the full role/action model from the docs:

- R01–R23 roles;
- PR/MP/SB/EX/WF action codes;
- permission legend;
- universal hard-no rules;
- **Project Coordinator**, not Project Engineer.

## Agent conduct

- Do not re-read files that are still within your current context or memory.
- Keep changes narrowly scoped to Wave 7 foundation implementation.
- Follow existing repo patterns; do not invent new architecture if a pattern already exists.
- Prefer extending existing PCC model/read-model/surface patterns over creating parallel structures.
- Do not overwrite unrelated working-tree changes.
- Stop and report if the repo has uncommitted changes in files you need to edit.
