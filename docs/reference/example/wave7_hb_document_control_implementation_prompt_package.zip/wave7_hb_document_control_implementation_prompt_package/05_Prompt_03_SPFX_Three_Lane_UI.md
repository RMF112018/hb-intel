# 05 — Prompt 03: SPFx Three-Lane UI Shell

## Objective

Update the existing PCC document surface to render **HB Document Control Center** as a three-lane UI using the read model/fixtures.

This prompt is UI/read-model only. It must not introduce live file operations.

## Required prerequisite

Prompt 01 and Prompt 02 should be complete or equivalent contracts/fixtures should already exist.

## Required repo audit first

Inspect:

```text
apps/project-control-center/src/surfaces/documents/
apps/project-control-center/src/surfaces/teamAccess/
apps/project-control-center/src/surfaces/projectHome/
apps/project-control-center/src/api/
packages/models/src/pcc/
```

Identify existing:
- surface layout patterns;
- card components;
- adapter/view-model patterns;
- tests.

Do not re-read files still in current context.

## UI target

Rename the surface/header where appropriate to:

```text
HB Document Control Center
```

Render three primary lanes:

1. `Project Record`
2. `My Project Files`
3. `External Systems`

Include a Reviews & Approvals section/summary if the existing surface pattern supports it. If not, represent review status inside Project Record and leave the dedicated Reviews & Approvals view for a later prompt.

## Project Record lane

Display:
- source status;
- SharePoint/project-library source label;
- sample formal project files;
- document type;
- approval status;
- reviewer/status;
- available/disabled actions.

No live actions. Buttons may be disabled or preview-only unless existing app pattern supports mock actions.

## My Project Files lane

Display:
- required warning text:

```text
Files in My Project Files are working files for this project. They are not part of the formal project record unless submitted to Project Record.
```

- only the current project folder label;
- personal working files from fixture/read model;
- `Submit to Project Record` as disabled/mock/preview-only unless explicitly already supported;
- source state such as pending initialization or folder creation failed.

Must not display:
- root folder children;
- other project folders;
- another user's files.

## External Systems lane

Display cards for:
- Procore;
- Adobe Sign;
- Document Crunch.

Show:
- configured / missing-config / access-issue / disabled;
- launch/status labels;
- no writeback/sync/mirror action.

## Guardrail UI requirements

The UI must communicate:
- no root `My Project Files` exposure;
- no other project folders;
- external systems remain linked systems of record;
- no external writeback;
- live file operations are not active unless later approved.

## Tests

Add/update tests to assert:
- title is HB Document Control Center;
- three lanes render;
- My Project Files warning renders;
- root/other project folder labels are not rendered;
- external writeback action is absent;
- Project Coordinator appears where role sample data includes it;
- no Project Engineer label in current-target Wave 7 UI.

## Validation

Run targeted UI tests.

Also run:

```bash
git diff --check
md5 pnpm-lock.yaml
git status --short
```

## Final response format

Return:

1. Files changed.
2. UI lanes implemented.
3. Guardrails rendered.
4. Tests added/updated.
5. Validation results.
6. Next prompt recommendation.
