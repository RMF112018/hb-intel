# 08 — Reviewer Prompt

Use this prompt in a fresh review session after the local code agent completes the first Wave 7 implementation slice.

---

You are reviewing a completed implementation slice in `/Users/bobbyfetting/hb-intel` for **Phase 3 / Wave 7 — HB Document Control Center**.

## Objective

Determine whether the implementation correctly scaffolds the HB Document Control Center foundation without violating Wave 7 safety boundaries.

## Required review checks

1. Confirm Wave 7 implementation aligns with commit `1c90b66db` documentation.
2. Confirm the implementation includes three lanes:
   - Project Record
   - My Project Files
   - External Systems
3. Confirm source registry/read-model contracts exist.
4. Confirm `procoreProjectId` exists in relevant project/document metadata posture.
5. Confirm My Project Files model uses:
   - root folder `My Project Files`;
   - project folder `{ProjectNumber}-{ProjectName}`;
   - current project only.
6. Confirm hard guardrail:
   - no full root exposure;
   - no other project folder exposure.
7. Confirm permission/action model includes:
   - R01–R23 roles;
   - PR/MP/SB/EX/WF action codes;
   - permission legend;
   - universal hard-no rules.
8. Confirm **Project Coordinator** is used and **Project Engineer** is not used in the current-target Wave 7 role/action model.
9. Confirm external/deferred roles have no default Wave 7 authority.
10. Confirm no external writeback/sync/mirror.
11. Confirm no live Graph/PnP/SharePoint REST/Procore/Adobe/Document Crunch runtime.
12. Confirm no package, lockfile, manifest, deployment, workflow, tenant, or secret changes.
13. Confirm tests prove the guardrails.

## Required commands

```bash
cd /Users/bobbyfetting/hb-intel
git status --short
md5 pnpm-lock.yaml
git diff --check
git diff --stat HEAD
git diff --name-only HEAD
```

Search for forbidden patterns in changed files and relevant Wave 7 areas:

```bash
rg -n "GraphServiceClient|@pnp|spfi\(|createUploadSession|driveItem|createLink|Procore|Adobe|Document Crunch|writeback|sync|mirror|Project Engineer" packages apps backend docs
```

Search for required patterns:

```bash
rg -n "HB Document Control Center|Project Record|My Project Files|External Systems|Project Document Source Registry|procoreProjectId|Project Coordinator|R01|R23|PR01|MP01|SB01|EX01|WF01|HARD-NO" packages apps backend docs
```

## Output format

Return:

1. Verdict: Pass / Pass with minor issues / Fail.
2. Evidence summary.
3. Files reviewed.
4. Guardrails confirmed.
5. Missing/conflicting items.
6. Specific remediation recommendations.
7. Whether the implementation is ready for the next Wave 7 prompt.
