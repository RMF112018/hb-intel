# 07 — Prompt 05: Closeout Docs and Validation

## Objective

Close out the first HB Document Control Center Wave 7 implementation slice with documentation and validation evidence.

## Required repo audit

Before editing closeout docs, inspect existing wave closeout patterns:

```bash
rg -n "Wave_.*Closeout|Closeout — Wave|Validation results|No tenant mutation|No package" docs/architecture/blueprint/sp-project-control-center/phase-3
```

Inspect likely locations:

```text
docs/architecture/blueprint/sp-project-control-center/phase-3/wave-7/
docs/architecture/blueprint/sp-project-control-center/phase-3/wave-6/
docs/architecture/blueprint/sp-project-control-center/phase-3/wave-5/
```

## Required closeout content

Add/update a closeout doc if repo pattern supports it.

The closeout must document:

1. Scope completed.
2. Files changed.
3. Model contracts added/updated.
4. Fixtures/read-models added/updated.
5. UI surface updates.
6. Permission/action model and guardrails.
7. Tests run.
8. Validation evidence.
9. Explicit exclusions:
   - no live Graph;
   - no OneDrive runtime folder creation;
   - no upload/download/copy-link runtime;
   - no Procore/Adobe/Document Crunch runtime;
   - no external writeback;
   - no tenant mutation;
   - no package/lockfile changes;
   - no deployment/manifest/workflow changes.
10. Residual issues/deferred next steps.

## Required validation commands

Run:

```bash
git status --short
md5 pnpm-lock.yaml
git diff --check
git diff --stat HEAD
git diff --name-only HEAD
```

Run targeted tests/type checks based on changed files. Suggested possibilities, subject to repo scripts:

```bash
pnpm --filter @hbc/models test
pnpm --filter @hbc/models typecheck
pnpm --filter @hbc/spfx-project-control-center test
pnpm --filter @hbc/spfx-project-control-center typecheck
pnpm test -- --runInBand
pnpm exec vitest run <specific-test-files>
```

Do not run broad install/add/update commands.

## Commit guidance

Commit only Wave 7 implementation files. Do not include unrelated working-tree changes.

Suggested commit:

```text
feat(spfx-pcc): scaffold hb document control center foundation
```

Commit description:

```text
Adds the Phase 3 Wave 7 HB Document Control Center foundation.

Introduces read-model/source-registry contracts, deterministic fixtures/mock provider coverage, three-lane Project Record/My Project Files/External Systems UI posture, permission/action guardrails, and tests proving no My Project Files root exposure, no other-project exposure, no external writeback, and no default live Graph operations.

No live Microsoft Graph file operations, OneDrive folder creation runtime, Procore/Adobe/Document Crunch runtime, external writeback, tenant mutation, deployment, package, manifest, workflow, or lockfile changes.
```

## Final response format

Return:

1. Commit hash if committed.
2. Commit summary/description.
3. Files changed.
4. Validation commands/results.
5. Explicit exclusions preserved.
6. Recommended next implementation prompt.
