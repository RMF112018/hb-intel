# 06 — Prompt 04: Permission/Action Model and Guardrails

## Objective

Implement the HB Document Control Center permission/action model in fixture/read-model/UI form and add guardrail tests.

This prompt does not authorize backend authorization enforcement for live operations. It implements the read-model/UI foundation and tests.

## Required prerequisite

Prompts 01–03 should be complete or equivalent source/read-model/UI scaffolding should exist.

## Required architecture content

Use the Wave 7 docs and model contracts to represent:

- R01–R23 roles;
- PR01–PR12 actions;
- MP01–MP09 actions;
- SB01–SB08 actions;
- EX01–EX04 actions;
- WF01–WF08 actions;
- permission symbols:
  - `Y`
  - `A`
  - `O`
  - `R`
  - `C`
  - `S`
  - `D`
  - `N`
  - `HARD-NO`

## Critical role requirements

Use:

```text
Project Coordinator
```

Do not use:

```text
Project Engineer
```

Represent external/deferred roles but do not grant them default Wave 7 authority.

## Required universal hard-no rules

The implementation must represent and test:

1. Browse full OneDrive root from project-site module — HARD-NO.
2. Browse full `My Project Files` root from project-site module — HARD-NO.
3. Browse another project’s `My Project Files` folder — HARD-NO.
4. Browse another user’s OneDrive through normal project UI — HARD-NO.
5. External writeback/sync/mirror in Wave 7 — HARD-NO.
6. Procore replacement workflow — HARD-NO.
7. Document Crunch replication — HARD-NO.
8. Adobe Sign agreement execution in Wave 7 — HARD-NO.
9. Anonymous sharing links — HARD-NO.
10. SPFx direct broad Graph file execution — HARD-NO.
11. Automatic external sharing — HARD-NO.
12. Automatic deletion of OneDrive working files when removed from project — HARD-NO.

## Implementation options

Depending on repo patterns, implement as one or more of:

- exported constant matrix in `packages/models/src/pcc/DocumentControl.ts`;
- read-model action availability arrays;
- fixture-derived allowed/disabled actions;
- UI action chips/badges;
- guardrail warning cards.

Do not create a second conflicting capability model if the repo already has one. Extend the current model or clearly mark this as Document Control actor/action posture.

## Tests

Add/update tests to prove:

- R01–R23 roles exist.
- Project Coordinator exists.
- Project Engineer is absent from current-target Wave 7 role/action matrix.
- PR/MP/SB/EX/WF action codes exist.
- universal hard-no rules exist.
- My Project Files root browsing is never allowed.
- Other-project folder browsing is never allowed.
- External writeback action is never allowed.
- External/deferred roles have deferred/no default action authority.
- Permission/action model serializes cleanly.

## Validation

Run targeted tests and type checks according to repo patterns.

Also run:

```bash
git diff --check
md5 pnpm-lock.yaml
git status --short
```

## Final response format

Return:

1. Files changed.
2. Permission/action model implementation summary.
3. Guardrail test summary.
4. Validation results.
5. Residual risks or next prompt recommendation.
