# 03 — Prompt 01: Source Registry and Shared Contracts

## Objective

Implement the shared model contracts for **HB Document Control Center** Phase 3 / Wave 7 foundation.

This prompt must produce source-registry/read-model contract scaffolding only. It must not introduce live file operations.

## Required repo audit first

Follow `01_Repo_Truth_Audit.md`, especially the model and read-model sections.

## Implementation target

Extend the existing PCC model vocabulary to support:

1. Three lanes:
   - `Project Record`
   - `My Project Files`
   - `External Systems`

2. Project Document Source Registry:
   - project metadata;
   - `procoreProjectId`;
   - SharePoint project binding;
   - document library bindings;
   - My Project Files binding policy;
   - user/project working folder binding;
   - external source bindings.

3. Source health states:
   - `available`
   - `loading`
   - `missing-config`
   - `access-issue`
   - `source-unavailable`
   - `throttled`
   - `partial-results`
   - `folder-not-created`
   - `folder-creation-failed`
   - `pending-initialization`
   - `disabled`

4. Action codes:
   - PR01–PR12
   - MP01–MP09
   - SB01–SB08
   - EX01–EX04
   - WF01–WF08

5. Role/action vocabulary:
   - R01–R23 role codes;
   - Project Coordinator instead of Project Engineer;
   - permission legend;
   - universal hard-no rules.

6. Workflow vocabulary:
   - Draft
   - Submitted
   - Under Review
   - Approved
   - Rejected
   - Returned for Revision
   - Superseded
   - Archived

7. Review types:
   - PM Review
   - PX Review
   - Operations Review
   - Accounting / Admin Review
   - Lead Estimator Review
   - Chief Estimator Review
   - Legal Review
   - Compliance Review
   - Leadership Review
   - Custom Internal Review

## Likely files

Use repo truth to confirm, but expected files include:

```text
packages/models/src/pcc/DocumentControl.ts
packages/models/src/pcc/PccReadModels.ts
packages/models/src/pcc/index.ts
```

Add tests if model tests exist in the same package pattern.

## Required guardrails

Model contracts must represent:

- `My Project Files` root exists in OneDrive, but project-site UI can only resolve the current project folder.
- Browsing the root `My Project Files` folder is `HARD-NO`.
- Browsing other project folders is `HARD-NO`.
- External writeback/sync/mirror is `HARD-NO`.
- Procore, Document Crunch, and Adobe Sign are launch/status sources only for Wave 7.

## Forbidden

Do not add:
- Graph clients;
- PnP clients;
- SharePoint REST calls;
- Procore SDK/API;
- Adobe Sign SDK/API;
- Document Crunch SDK/API;
- write-route implementation;
- tenant mutation;
- package dependencies.

## Validation

Run targeted tests/type checks consistent with the repo pattern.

At minimum:

```bash
git diff --check
md5 pnpm-lock.yaml
git status --short
```

If package-level test scripts exist for `@hbc/models`, run the targeted model tests or typecheck.

## Final response format

Return:

1. Files changed.
2. Contract types/enums added or updated.
3. Guardrails represented.
4. Validation commands and results.
5. Residual risks or next prompt recommendation.
